import React from 'react';
import SmmPanel from './SmmPanel';

export default function App() {
  return <SmmPanel />;
}