import React, { useState } from "react";

export default function SmmPanel() {
  const [user, setUser] = useState({ name: "Guest", balance: 100.0 });
  const [packages] = useState([
    { id: 1, name: "Instagram Likes", price: 5, rate: "100 likes", delivery: "1-6 hrs" },
    { id: 2, name: "Instagram Followers", price: 12, rate: "500 followers", delivery: "6-24 hrs" },
    { id: 3, name: "YouTube Views", price: 8, rate: "1000 views", delivery: "24-72 hrs" },
    { id: 4, name: "TikTok Likes", price: 4, rate: "100 likes", delivery: "1-4 hrs" },
  ]);

  const [selectedPackage, setSelectedPackage] = useState(null);
  const [orders, setOrders] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [query, setQuery] = useState("");

  function openOrder(pkg) {
    setSelectedPackage({ ...pkg, quantity: 1, link: "" });
  }

  function placeOrder() {
    if (!selectedPackage) return;
    if (!selectedPackage.link || selectedPackage.link.length < 5) {
      alert("Please provide a valid target link or username.");
      return;
    }
    const cost = selectedPackage.price * selectedPackage.quantity;
    if (cost > user.balance) {
      alert("Insufficient balance. Please add funds.");
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      const newOrder = {
        id: Date.now(),
        pkg: selectedPackage.name,
        quantity: selectedPackage.quantity,
        link: selectedPackage.link,
        status: "Processing",
        placedAt: new Date().toLocaleString(),
      };
      setOrders((s) => [newOrder, ...s]);
      setUser((u) => ({ ...u, balance: +(u.balance - cost).toFixed(2) }));
      setSelectedPackage(null);
      setIsProcessing(false);
      alert("Order placed successfully!");
    }, 900);
  }

  function fakeAddFunds() {
    setUser((u) => ({ ...u, balance: +(u.balance + 50).toFixed(2) }));
  }

  function toggleAdmin() {
    setIsAdmin((s) => !s);
  }

  const filteredPackages = packages.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="min-h-screen p-6">
      <header className="max-w-6xl mx-auto flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 text-white font-bold px-3 py-2 rounded">SMMCHEAPEST</div>
          <h1 className="text-2xl font-semibold">SMM Panel</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm">
            <div>Hello, <strong>{user.name}</strong></div>
            <div className="text-xs text-gray-600">Balance: ₹{user.balance.toFixed(2)}</div>
          </div>
          <button onClick={fakeAddFunds} className="bg-green-500 text-white px-3 py-2 rounded text-sm">Add ₹50</button>
          <button onClick={toggleAdmin} className={`px-3 py-2 rounded text-sm ${isAdmin ? 'bg-red-500 text-white' : 'bg-gray-200'}`}>
            {isAdmin ? 'Admin Mode' : 'User Mode'}
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6">
        <aside className="md:col-span-1 bg-white p-4 rounded shadow">
          <div className="mb-4">
            <input className="w-full border p-2 rounded" placeholder="Search packages..." value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <nav className="space-y-2 text-sm">
            <a className="block p-2 rounded hover:bg-gray-50">Dashboard</a>
            <a className="block p-2 rounded hover:bg-gray-50">Packages</a>
            <a className="block p-2 rounded hover:bg-gray-50">Orders</a>
            <a className="block p-2 rounded hover:bg-gray-50">Transactions</a>
            {isAdmin && <a className="block p-2 rounded text-red-600 hover:bg-gray-50">Admin: Manage</a>}
          </nav>
        </aside>

        <section className="md:col-span-3">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
            <div className="bg-white p-4 rounded shadow">
              <div className="text-sm text-gray-600">Orders</div>
              <div className="text-2xl font-bold">{orders.length}</div>
            </div>
            <div className="bg-white p-4 rounded shadow">
              <div className="text-sm text-gray-600">Available Packages</div>
              <div className="text-2xl font-bold">{packages.length}</div>
            </div>
            <div className="bg-white p-4 rounded shadow">
              <div className="text-sm text-gray-600">Balance</div>
              <div className="text-2xl font-bold">₹{user.balance.toFixed(2)}</div>
            </div>
          </div>

          <div className="bg-white p-4 rounded shadow mb-6">
            <h2 className="font-semibold mb-3">Packages</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredPackages.map((pkg) => (
                <div key={pkg.id} className="border rounded p-3">
                  <div className="font-semibold">{pkg.name}</div>
                  <div className="text-sm text-gray-600">{pkg.rate}</div>
                  <div className="text-sm text-gray-500">Delivery: {pkg.delivery}</div>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="font-bold">₹{pkg.price}</div>
                    <button onClick={() => openOrder(pkg)} className="text-sm bg-blue-600 text-white px-2 py-1 rounded">Order</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h2 className="font-semibold mb-3">Recent Orders</h2>
            {orders.length === 0 && <div className="text-sm text-gray-500">No orders yet.</div>}
            <ul className="space-y-2">
              {orders.map((o) => (
                <li key={o.id} className="border rounded p-2 flex items-center justify-between">
                  <div>
                    <div className="font-medium">{o.pkg}</div>
                    <div className="text-xs text-gray-500">{o.quantity} • {o.link}</div>
                  </div>
                  <div className="text-sm">
                    <div>{o.status}</div>
                    <div className="text-xs text-gray-400">{o.placedAt}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>

      {selectedPackage && (
        <div className="fixed inset-0 z-40 flex items-end md:items-center justify-center p-4">
          <div className="absolute inset-0 bg-black opacity-40" onClick={() => setSelectedPackage(null)}></div>
          <div className="relative bg-white w-full md:w-2/5 rounded shadow p-6 z-50">
            <h3 className="font-semibold text-xl mb-2">Order: {selectedPackage.name}</h3>
            <div className="mb-2 text-sm text-gray-600">Price per unit: ₹{selectedPackage.price}</div>

            <label className="block text-sm mb-1">Target link or username</label>
            <input className="w-full border p-2 rounded mb-3" placeholder="e.g. https://instagram.com/username or @username" value={selectedPackage.link} onChange={(e)=> setSelectedPackage({...selectedPackage, link: e.target.value})} />

            <label className="block text-sm mb-1">Quantity</label>
            <input type="number" min={1} className="w-40 border p-2 rounded mb-3" value={selectedPackage.quantity} onChange={(e)=> {
              const q = Math.max(1, Number(e.target.value || 1));
              setSelectedPackage({...selectedPackage, quantity: q});
            }} />

            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-gray-600">Total: ₹{(selectedPackage.price * selectedPackage.quantity).toFixed(2)}</div>
              <div className="flex items-center gap-2">
                <button onClick={() => setSelectedPackage(null)} className="px-3 py-2 rounded border">Cancel</button>
                <button onClick={placeOrder} disabled={isProcessing} className="px-3 py-2 rounded bg-blue-600 text-white disabled:opacity-60">{isProcessing ? 'Placing...' : 'Place Order'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <footer className="max-w-6xl mx-auto mt-8 text-center text-sm text-gray-500">
        <div>SMMCHEAPEST • Starter Panel</div>
        <div className="mt-2">Customize packages, pricing & payment integration as needed.</div>
      </footer>
    </div>
  );
}